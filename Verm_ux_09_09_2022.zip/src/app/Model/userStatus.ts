export class userStatus{
  email!:string;
  emp_name!:string;
  emp_status!:string;
  employee_id!:number;
  img!:string;
  personal_cnct_no!:string;
  position!:string;
  team_id!:number;
  team_name!:string;
  user_status!:string;
  user_type!:string;
}
