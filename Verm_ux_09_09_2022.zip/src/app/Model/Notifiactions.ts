export class Notifiactions {

  public activity!: string;
  public admin!: string;
  public id!: number;
  public narration!: string;
  public user!: number;
  public view_flag!: string;
  public total!:string;
}
