export class IncDetails{
  public id!:Number
  public Inc_Name!: string;
  public Inc_location!:string;
  public tier!:string;
  public hours!:number;
  public Inc_type!:string;
  public tot_casualty!:string;
  public lat!:string;
  public lon!:string;
  public offshore_name!:string
  public inc_no!:string
  public initial_tier_id!:string;

}
