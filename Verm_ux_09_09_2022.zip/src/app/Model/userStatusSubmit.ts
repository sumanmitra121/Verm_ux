export class userStatus{
   public  user:any;
   public  emp_id!:number;
   public emp_name!: string;
   public user_status!: string;
}